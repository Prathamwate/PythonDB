import pymysql


con=pymysql.connect(host='bwcbbjh8c40a4f5ueqri-mysql.services.clever-cloud.com', user='uorw3mucjoaap7by', password='MJkVbV7X4tzTD5IHV6dv',database='bwcbbjh8c40a4f5ueqri')
curs=con.cursor()
bookc=input("Enter the Book code: ")
curs.execute("select * from Books where Bookcode='%s'" %bookc)
data=curs.fetchone()
try:
    print("Book name : '%s'" %data[1])
    rw=input("enter the review of book: ")
    curs.execute("update Books set review ='%s' where Bookcode='%s'" %(rw,bookc))
    print("Review uploaded successfully")
    con.commit()
except Exception as e:
    print(e)  

con.close()
