from contextlib import nullcontext
import pymysql


con=pymysql.connect(host='bwcbbjh8c40a4f5ueqri-mysql.services.clever-cloud.com', user='uorw3mucjoaap7by', password='MJkVbV7X4tzTD5IHV6dv',database='bwcbbjh8c40a4f5ueqri')
curs=con.cursor()
bckd=input("enter the bookcode you want to search: ")
curs.execute("select * from Books where bookcode=%s" %bckd)
data=curs.fetchone()
try:
    print('Book code      : %s' %data[0])
    print('Book Name      : %s' %data[1])
    print('Category       : %s' %data[2])
    print('Author         : %s' %data[3])
    print('Publication    : %s' %data[4])
    print('Edition        : %s' %data[5])
    print('Price          : %s' %data[6])
except:
    print('Book does not exist')

con.close()