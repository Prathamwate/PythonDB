import pymysql


con=pymysql.connect(host='bwcbbjh8c40a4f5ueqri-mysql.services.clever-cloud.com', user='uorw3mucjoaap7by', password='MJkVbV7X4tzTD5IHV6dv',database='bwcbbjh8c40a4f5ueqri')
curs=con.cursor()

try:
    code=input("Enter book code : ")
    curs.execute("select * from Books where Bookcode='%s'" %code)
    data=curs.fetchone()
    if data:
        n=input("do you want to delete ?(yes / no)")
        if n.lower() =='yes':
            curs.execute("delete from Books where Bookcode='%s' " %code)
            con.commit()
            print("delete record successfully")
    else:
        print("Book does not found")
except Exception as e:
    print(e)                 
