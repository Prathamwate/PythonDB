import pymysql

cat=input("Enter the category of Books you Want to see: ")
con=pymysql.connect(host='bwcbbjh8c40a4f5ueqri-mysql.services.clever-cloud.com', user='uorw3mucjoaap7by', password='MJkVbV7X4tzTD5IHV6dv',database='bwcbbjh8c40a4f5ueqri')
curs=con.cursor()

try:
  curs.execute("select * from Books where Category='%s' " %cat)
  data=curs.fetchall()
  print(data)

  con.close()

except Exception as e:
    print(e)  

