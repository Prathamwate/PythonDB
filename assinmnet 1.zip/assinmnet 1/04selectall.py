import pymysql


con=pymysql.connect(host='bwcbbjh8c40a4f5ueqri-mysql.services.clever-cloud.com', user='uorw3mucjoaap7by', password='MJkVbV7X4tzTD5IHV6dv',database='bwcbbjh8c40a4f5ueqri')
curs=con.cursor()

curs.execute("select * from Books")
data=curs.fetchall()

for rec in data:
  print(rec)

con.close()