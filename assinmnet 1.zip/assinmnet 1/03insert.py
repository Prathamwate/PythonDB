import pymysql

try:
    con=pymysql.connect(host='bwcbbjh8c40a4f5ueqri-mysql.services.clever-cloud.com', user='uorw3mucjoaap7by', password='MJkVbV7X4tzTD5IHV6dv',database='bwcbbjh8c40a4f5ueqri')
    curs=con.cursor()
    bkcd=input("Enter the book code: ")
    bknm=input("Enter the Book Name: ")
    Cate=input("Enter the books category: ")
    author=input("ENter the Name of author of book: ")
    publ=input("Enter the name of publicatiopn: ")
    edition=input("Enter the edition of book: ")
    price=int(input("Enter the price of book: "))
    
    curs.execute("insert into Books values(%s,'%s','%s','%s','%s','%s',%d)" %(bkcd,bknm,Cate,author,publ,edition,price))
    con.commit()
    print("New Book is successfully Added")

    con.close()
except:
    print("failed")