import pymysql


con=pymysql.connect(host='bwcbbjh8c40a4f5ueqri-mysql.services.clever-cloud.com', user='uorw3mucjoaap7by', password='MJkVbV7X4tzTD5IHV6dv',database='bwcbbjh8c40a4f5ueqri')
curs=con.cursor()

try:
    code=input("Enter book code : ")
    curs.execute("select * from Books where Bookcode='%s'" %code)
    #data=curs.fetchone()
    nprice=int(input("Enter new price: "))
    curs.execute("update Books set price=%d where Bookcode='%s'" %(nprice,code))
    con.commit()
    print("update successfully")
    con.close()
except Exception as e:
    print(e)    